// Copyright 2020 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

/**
 * Branded type used for CSS text bundled with our `*.css.js` files.
 */
type CSSInJS = string&{_tag: 'CSS-in-JS'};

declare module '*.css.js' {
  const styles: CSSInJS;
  export default styles;
}

declare module '*.skill.js' {
  // Duplicated from front_end/models/ai_assistance/skills/Skill.ts
  // to avoid importing from the source tree in a global declaration file,
  // which was causing build artifacts to be generated in the source tree.
  interface Skill {
    name: 'styling';
    description: string;
    allowedTools: string[];
    instructions: string;
  }
  export const skill: Skill;
}

// TODO: remove once URLPattern types are available in TypeScript (see https://github.com/microsoft/TypeScript-DOM-lib-generator/issues/1199).
declare class URLPattern {
  constructor(input: string);
  hash: string;
  hostname: string;
  password: string;
  pathname: string;
  port: string;
  protocol: string;
  search: string;
  username: string;
  hasRegExpGroups: boolean;
  test(url: string): boolean;
  prototype: URLPattern;
}

// [start] Types for the Scheduler API.
// These are taken from
// https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/wicg-task-scheduling
// but modified because within Chrome we can use the API without worrying that
// it is undefined.
// This code is licensed under the MIT license
/**
 * MIT License
 * Copyright (c) Microsoft Corporation.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE
 */
type PostTaskPriority = 'user-blocking'|'user-visible'|'background';

interface PostTaskOptions {
  priority?: PostTaskPriority;
  signal?: AbortSignal;
  delay?: number;
}

interface Scheduler {
  yield(): Promise<void>;
  postTask<T>(callback: () => T): Promise<T>;
  postTask<T>(callback: () => T, options: PostTaskOptions): Promise<T>;
}

interface Window {
  readonly scheduler: Scheduler;

  // Chromium only feature so not exposed on TypeScript lib.dom
  showSaveFilePicker(opts: {
    suggestedName: string,
  }): Promise<FileSystemFileHandle>;
}

interface WorkerGlobalScope {
  readonly scheduler?: Scheduler;
}
// [end] Types for the Scheduler API.

// [start] Type definition for EyeDropper

interface EyeDropper {
  open: (options?: {signal?: AbortSignal}) => Promise<{sRGBHex: string}>;
}

interface Window {
  // eslint-disable-next-line @typescript-eslint/naming-convention
  EyeDropper: {new(): EyeDropper};
}

// [end] Type definition for EyeDropper
